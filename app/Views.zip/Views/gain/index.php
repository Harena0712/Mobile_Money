<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Situation des gains</title>
</head>
<body>
    <main>
        <h1>Situation des gains</h1>

        <div>
            <p><strong>Total des frais :</strong> <?= esc($total_frais) ?> </p>
            <p><strong>Total des frais de transfert :</strong> <?= esc($total_frais_transfert) ?> </p>
            <p><strong>Total des frais de retrait :</strong> <?= esc($total_frais_retrait) ?> </p>
            <p><strong>Total des dépôts :</strong> <?= esc($total_depots) ?> </p>
            <p><strong>Total des transferts :</strong> <?= esc($total_transferts) ?> </p>
            <p><strong>Total des retraits :</strong> <?= esc($total_retraits) ?> </p>
            <p><strong>Total commissions inter-opérateurs :</strong> <?= esc($total_commissions_interoperateurs) ?> </p>
        </div>

        <?php if (! empty($gains_par_operateur)) : ?>
            <section>
                <h2>Gains par opérateur</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Opérateur</th>
                            <th>Total frais</th>
                            <th>Frais transferts</th>
                            <th>Frais retraits</th>
                            <th>Dépôts</th>
                            <th>Transferts</th>
                            <th>Retraits</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($gains_par_operateur as $gain) : ?>
                            <tr>
                                <td><?= esc($gain['operateur']) ?></td>
                                <td><?= esc(number_format($gain['total_frais'], 2, '.', ' ')) ?></td>
                                <td><?= esc(number_format($gain['total_frais_transfert'], 2, '.', ' ')) ?></td>
                                <td><?= esc(number_format($gain['total_frais_retrait'], 2, '.', ' ')) ?></td>
                                <td><?= esc($gain['total_depots']) ?></td>
                                <td><?= esc($gain['total_transferts']) ?></td>
                                <td><?= esc($gain['total_retraits']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </section>
        <?php endif; ?>
    </main>
</body>
</html>
