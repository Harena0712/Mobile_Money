<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($title) ? esc($title) . ' · MoneyFlow' : 'MoneyFlow' ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
</head>
<body class="client-body">

<div class="client-shell">

    <header class="client-topbar">
        <a href="/client/solde" class="client-brand">
            <span class="brand-mark">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="2" y="5" width="20" height="14" rx="3" stroke="currentColor" stroke-width="1.8"/>
                    <path d="M2 9.5H22" stroke="currentColor" stroke-width="1.8"/>
                    <circle cx="17" cy="14.5" r="1.6" fill="currentColor"/>
                </svg>
            </span>
            <span class="brand-name">MoneyFlow</span>
        </a>

        <?php if (strpos(current_url(), '/client/login') === false) : ?>
            <a href="/client/logout" class="client-logout">
                Déconnexion
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </a>
        <?php endif; ?>
    </header>

    <main class="client-content">
        <?= $this->renderSection('content') ?>
    </main>

</div>

</body>
</html>
